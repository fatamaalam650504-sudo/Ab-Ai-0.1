package com.abai.app
import org.json.*
import java.net.HttpURLConnection
import java.net.URL

object Agent {
    const val FAST = "claude-haiku-5-5"   // loop: fast
    const val SMART = "claude-sonnet-5-5" // planning: smarter
    private const val SYS = "You are AB Ai, an assistant controlling the user's Android phone. " +
        "Each turn you see the screen as numbered elements. Use ONE tool at a time to reach the goal. " +
        "Call done(message) when finished or if you need the user's answer. Reply in the user's language (Bangla if they use Bangla). " +
        "ALWAYS ask the user (via done) before payments, deleting data, or sending messages/emails unless they explicitly said to."

    private fun tool(n: String, d: String, vararg p: Pair<String, String>): JSONObject {
        val props = JSONObject(); p.forEach { props.put(it.first, JSONObject().put("type", it.second)) }
        return JSONObject().put("name", n).put("description", d).put("input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(p.map { it.first })))
    }
    private val TOOLS = JSONArray(listOf(
        tool("click", "Tap element by index", "index" to "integer"),
        tool("type", "Type text into input element", "index" to "integer", "text" to "string"),
        tool("scroll", "Scroll down or up", "direction" to "string"),
        tool("back", "Press back"), tool("home", "Go to home screen"),
        tool("open_app", "Open an app by name", "name" to "string"),
        tool("dial", "Open dialer with number", "number" to "string"),
        tool("done", "Finish; message is spoken to the user", "message" to "string")))

    private fun user(t: String) = JSONObject().put("role", "user").put("content", t)

    private fun call(key: String, model: String, system: String, msgs: JSONArray, tools: JSONArray?): JSONObject {
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 60000
        c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        val b = JSONObject().put("model", model).put("max_tokens", 1024).put("system", system).put("messages", msgs)
        if (tools != null) b.put("tools", tools)
        c.outputStream.use { it.write(b.toString().toByteArray()) }
        val s = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        return JSONObject(s)
    }

    fun run(svc: PhoneService, key: String, goal: String, say: (String) -> Unit) {
        try {
            val plan = call(key, SMART, "Plan tasks on an Android phone. Short numbered plan, max 6 steps, English.",
                JSONArray().put(user(goal)), null).getJSONArray("content").getJSONObject(0).optString("text")
            val msgs = JSONArray().put(user("Goal: $goal\nPlan:\n$plan\n\nScreen:\n${svc.screen()}"))
            repeat(20) {
                val r = call(key, FAST, SYS, msgs, TOOLS)
                if (r.has("error")) { say("Error: " + r.getJSONObject("error").optString("message")); return }
                val content = r.getJSONArray("content")
                msgs.put(JSONObject().put("role", "assistant").put("content", content))
                val results = JSONArray(); var finished = false; var text = ""
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.getString("type") == "text") text += b.optString("text")
                    if (b.getString("type") != "tool_use") continue
                    val inp = b.getJSONObject("input")
                    val out = if (b.getString("name") == "done") { say(inp.optString("message")); finished = true; "ok" }
                              else svc.act(b.getString("name"), inp)
                    results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out))
                }
                if (finished) return
                if (results.length() == 0) { say(text); return }
                Thread.sleep(1200)
                results.put(JSONObject().put("type", "text").put("text", "Screen now:\n" + svc.screen()))
                msgs.put(JSONObject().put("role", "user").put("content", results))
            }
            say("Step limit e pouchhe gechi, kaj ekhono shesh hoy ni.")
        } catch (e: Exception) { say("Error: ${e.message}") }
    }
}
