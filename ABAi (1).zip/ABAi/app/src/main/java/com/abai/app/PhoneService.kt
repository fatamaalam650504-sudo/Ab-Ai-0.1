package com.abai.app
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeInfo.*
import org.json.JSONObject

class PhoneService : AccessibilityService() {
    companion object { var inst: PhoneService? = null }
    private val nodes = ArrayList<AccessibilityNodeInfo>()
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    fun screen(): String {
        nodes.clear()
        val sb = StringBuilder("app: ${rootInActiveWindow?.packageName}\n")
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()
            if (t != null || n.isClickable || n.isEditable) {
                val kind = if (n.isEditable) "input" else if (n.isClickable) "button" else "text"
                sb.append("[${nodes.size}] $kind: ${t ?: ""}\n"); nodes.add(n)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString().take(6000)
    }

    private fun launch(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun act(name: String, a: JSONObject): String = try { when (name) {
        "click" -> {
            var n = nodes.getOrNull(a.getInt("index"))
            while (n != null && !n.isClickable) n = n.parent
            if (n?.performAction(ACTION_CLICK) == true) "clicked" else "click failed"
        }
        "type" -> {
            val n = nodes.getOrNull(a.getInt("index"))
            val b = Bundle().apply { putCharSequence(ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.getString("text")) }
            if (n?.performAction(ACTION_SET_TEXT, b) == true) "typed" else "type failed"
        }
        "scroll" -> {
            val n = nodes.firstOrNull { it.isScrollable }
            val act = if (a.getString("direction") == "up") ACTION_SCROLL_BACKWARD else ACTION_SCROLL_FORWARD
            if (n?.performAction(act) == true) "scrolled" else "nothing to scroll"
        }
        "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "back" }
        "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "home" }
        "open_app" -> {
            val q = a.getString("name").lowercase()
            val pm = packageManager
            val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = l.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            if (hit != null) { launch(pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!); "opened" } else "app not found"
        }
        "dial" -> { launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.getString("number")))); "dialer opened" }
        else -> "unknown tool"
    } } catch (e: Exception) { "error: ${e.message}" }
}
