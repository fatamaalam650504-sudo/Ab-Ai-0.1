package com.abai.app
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var keyBox: EditText
    private val prefs by lazy { getSharedPreferences("abai", MODE_PRIVATE) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tts = TextToSpeech(this) { tts.language = Locale("bn", "BD") }
        keyBox = EditText(this).apply { hint = "Anthropic API key"; setText(prefs.getString("key", "")) }
        log = TextView(this).apply { textSize = 16f; text = "AB Ai ready. Mic chepe bolo." }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40)
            addView(keyBox)
            addView(btn("Key save") { prefs.edit().putString("key", keyBox.text.toString().trim()).apply() })
            addView(btn("Accessibility on koro") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(btn("🎤 Bolo") { listen() })
            addView(log)
        }
        setContentView(ScrollView(this).apply { addView(col) })
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    private fun say(t: String) = runOnUiThread { log.append("\nAB Ai: $t"); tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "x") }

    private fun listen() {
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val goal = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                log.append("\nTumi: $goal")
                val svc = PhoneService.inst
                val key = prefs.getString("key", "") ?: ""
                if (svc == null) { say("Age Accessibility service chalu koro."); return }
                if (key.isEmpty()) { say("Age API key save koro."); return }
                Thread { Agent.run(svc, key, goal) { say(it) } }.start()
            }
            override fun onError(e: Int) { say("Shunte pari ni, abar bolo.") }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        })
    }
}
